﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CrudCoreOklab.Models
{
    public class Empleado
    {
        [Key]
        public int IdEmpleado { get; set; }
        public int IdTipoDocumento {  get; set; }
        public virtual TipoDocumento TipoDocumento { get; set; }
        public string DocumentoEmpleado{ get; set; }
        public string ContrasenhaEmpleado { get; set;}
        public string NombreEmpleado { get; set; }
        public string ApellidoEmpleado { get; set;}
        public string EmailEmpleado { get; set; }
        public string CelularEmpleado { get; set; }
        public int IdCargo { get; set; }
        public virtual Cargo Cargo { get; set; }
        public DateTime InicioContrato { get; set; }
        public string ARL { get; set; }
        public string EPS { get; set;}
        public string TipoSangre { get; set;}
    }
}
