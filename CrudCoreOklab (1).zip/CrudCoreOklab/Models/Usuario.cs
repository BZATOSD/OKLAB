﻿using System.ComponentModel.DataAnnotations;

namespace CrudCoreOklab.Models
{
    public class Usuario
    {
    }
}
