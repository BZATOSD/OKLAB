﻿using System.ComponentModel.DataAnnotations;

namespace CrudCoreOklab.Models
{
    public class Cargo
    {
        [Key]
        public int IdCargo { get; set; }
        public string NombreCargo {  get; set; }

        public virtual ICollection<Empleado> Empleados { get; set; }

    }
}
