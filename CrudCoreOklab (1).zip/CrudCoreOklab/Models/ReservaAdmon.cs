﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CrudCoreOklab.Models
{
    public class ReservaAdmon
    {
        [Key]
        public int IdReserva { get; set; }
        public int IdCliente { get; set; }
        public virtual Cliente Cliente { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int NombreHabitacion { get; set; }
        public virtual Habitacion Habitacion { get; set; }
        public int Reservar { get; set; }
        public int Eliminar { get; set; }

        public ReservaAdmon() { }

        public ReservaAdmon(DateTime fechaInicio, DateTime fechaFin, int nombreHabitacion)
        {
            FechaInicio = fechaInicio;
            FechaFin = fechaFin;
            NombreHabitacion = nombreHabitacion;
        }
    }
}
