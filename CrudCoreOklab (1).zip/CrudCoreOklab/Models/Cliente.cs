﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace CrudCoreOklab.Models
{
    public class Cliente
    {
        [Key]
        public int IdCliente { get; set; }  
        public required int IdTipoDocumento { get; set; }
        public virtual TipoDocumento TipoDocumento { get; set; }
        public required string DocumentoCliente { get; set; }
        public required string Contrasenha  { get; set; }
        public required string NombreCliente { get; set; }
        public required string ApellidoCliente { get; set; }
        public required string EmailCliente { get; set; }
        public required string CelularCliente { get; set; }
        public virtual ICollection<Reserva> Reservas { get; set; }
    }
}
