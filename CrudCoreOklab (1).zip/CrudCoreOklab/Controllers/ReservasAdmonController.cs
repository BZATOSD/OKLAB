﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CrudCoreOklab.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using CrudCoreOklab.Data;

namespace CrudCoreOklab.Controllers
{
    public class ReservasAdmonController : Controller
    {
        private readonly AppDbContext _context;

        public ReservasAdmonController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Obtener todas las reservas desde la base de datos
            var reservas = await _context.Reserva
                .Include(r => r.Cliente)       
                .Include(r => r.Habitacion)    
                .ToListAsync();

           
            return View(reservas);
        }
    }
}
