﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CrudCoreOklab.Data;
using CrudCoreOklab.Models;
using CrudCoreOklab.Migrations;

namespace CrudCoreOklab.Controllers
{
    public class ReservasController : Controller
    {
        private readonly AppDbContext _context;

        public ReservasController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Reservas
        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.Reserva.Include(r => r.Habitacion);
            return View(await appDbContext.ToListAsync());
        }

        public async Task<IActionResult> Historial(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reservas = await _context.Reserva
                .Include(r => r.Habitacion)
                .Where(r => r.IdCliente == id)
                .ToListAsync();

            if (reservas == null || reservas.Count == 0)
            {
                return NotFound();
            }

            return View(reservas);
        }


        // GET: Reservas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reserva
                .Include(r => r.Habitacion)
                .FirstOrDefaultAsync(m => m.IdReserva == id);
            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }

        // GET: Reservas/Create
        public IActionResult Create(int idCliente)
        {
            var modelo = new Reserva
            {
                IdCliente = idCliente,
                FechaInicio = DateTime.Now, 
                FechaFin = DateTime.Now.AddDays(1), 
            };
            ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "NombreHabitacion");
            return View(modelo);
        }

        // POST: Reservas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Create(Reserva reserva, int idCliente)
        {
            // Verifica si el cliente existe
            var cliente = await _context.Cliente.FindAsync(idCliente);
            if (cliente == null)
            {
                ModelState.AddModelError("", "Cliente no encontrado.");
                ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "NombreHabitacion");
                return View(reserva);
            }

            bool Disponible = !_context.Reserva.Any(r =>
                r.NombreHabitacion == reserva.NombreHabitacion &&
                r.FechaInicio < reserva.FechaFin &&
                r.FechaFin > reserva.FechaInicio);

            
                if (!Disponible)
                {
                    ModelState.AddModelError("", "La habitación ya está reservada en el rango de fechas especificado.");
                    ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "NombreHabitacion");
                    return View(reserva);
                }
                else
                {
                    reserva.IdCliente = idCliente;
                    await _context.Reserva.AddAsync(reserva);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Details", "Reservas", new { id = reserva.IdReserva, IdCliente = reserva.IdCliente });
                }
            

            ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "NombreHabitacion");
            return View(reserva);
        }

        // GET: Reservas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reserva.FindAsync(id);
            if (reserva == null)
            {
                return NotFound();
            }
            ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "IdHabitacion", reserva.NombreHabitacion);
            return View(reserva);
        }

        // POST: Reservas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdReserva,FechaInicio,FechaFin,NombreHabitacion")] Reserva reserva)
        {
            if (id != reserva.IdReserva)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reserva);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReservaExists(reserva.IdReserva))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["NombreHabitacion"] = new SelectList(_context.Set<Habitacion>(), "IdHabitacion", "IdHabitacion", reserva.NombreHabitacion);
            return View(reserva);
        }

        // GET: Reservas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reserva = await _context.Reserva
                .Include(r => r.Habitacion)
                .FirstOrDefaultAsync(m => m.IdReserva == id);
            if (reserva == null)
            {
                return NotFound();
            }

            return View(reserva);
        }

        // POST: Reservas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reserva = await _context.Reserva.FindAsync(id);
            if (reserva != null)
            {
                _context.Reserva.Remove(reserva);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReservaExists(int id)
        {
            return _context.Reserva.Any(e => e.IdReserva == id);
        }
    }
}
